package com.example.instilostandfound;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.Exclude;

import java.text.SimpleDateFormat;
import java.util.Date;

public class createDemo {
    //private String mImageUrl;
    private String mKey;
    private String mTitle;
    private String mDate;
    private String mLDAP;
    private String mDescription;
    private String mLocation;
   // private String mCategory;
    private String mDateFound;

    public createDemo() {

    }

    public createDemo(String LDAPID,String title ,  String desc,String location,
                              String datefound) {
        if (LDAPID.trim().equals("")) {
            mLDAP = "No Name";
        }

        //mLDAPID = LDAPID;
        //mImageUrl = imageUrl;
        mLDAP = LDAPID;
        mDescription = desc;
        mLocation = location;
        mDateFound = datefound;
        //mCategory = category;
        mTitle = title;

        SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
        Date date = new Date();
        mDate = df.format(date);



    }

    public String getLDAP() {
        return mLDAP;
    }
    public void setLDAP(String LDAP) { mLDAP= LDAP; }

    public String getmTitle() {
        return mTitle;
    }

    public void setmTitle(String mTitle) {
        this.mTitle = mTitle;
    }



    public String getmDateFound()
    { return mDateFound; }
    public void setmDateFound(String dateFound)
    { mDateFound = dateFound; }

    public String getmDescription()
    { return mDescription; }
    public void setmDescription(String desc)
    { mDescription = desc; }

    public String getmLocation()
    {return mLocation;}
    public void setmLocation(String location)
    { mLocation = location;}

    @Exclude
    public String getKey()
    {
        return mKey;
    }
    @Exclude
    public void setKey(String key)
    {
        mKey = key;
    }

    public String getDate()
    { return mDate; }
    public void setDate(String date)
    { mDate = date; }
}
