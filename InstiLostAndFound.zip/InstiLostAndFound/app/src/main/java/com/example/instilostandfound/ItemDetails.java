package com.example.instilostandfound;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

public class ItemDetails extends AppCompatActivity implements View.OnClickListener {
String category, name, key;
int type;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_details);

        Intent intent = getIntent();
        category = intent.getStringExtra("category");
        name = intent.getStringExtra("name");
        key = intent.getStringExtra("key");
        type = intent.getIntExtra("type",-1);
        TextView cat_row = (TextView) findViewById(R.id.category);
        cat_row.setText(category);
        TextView name_row = (TextView) findViewById(R.id.name);
        name_row.setText(name);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.edit_post:
                if(type == 0){
                    Intent intent = new Intent(ItemDetails.this, LostItem.class);
                    intent.putExtra("key", key);
                    startActivity(intent);
                }
                else if(type == 1){
                    Intent intent = new Intent(ItemDetails.this, FoundItem.class);
                    intent.putExtra("key", key);
                    startActivity(intent);
                }
                Log.d("..................", "hiiiiiiiiiii");
                break;
            case R.id.resolve_post:
                break;
        }
    }
}
